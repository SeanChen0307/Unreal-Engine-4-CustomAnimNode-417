specification:
1.Download the corresponding version of plugin package.
2.Copy the "CustomAnimNode" folder and paste it into the "Plugin" folder of which project you want to use this plugin.
3.Open the project and enable the plugin namde "CustomAnimNode".
4.Now you can create those new BP node inside the AnimGraph of animblueprint.

Caution:
To make those node work, your character's skeleton must have IK foot setup.

If you want to learn more, see official livestream "Paragon Feature Examples: Animation Techniques".

Link:
https://www.youtube.com/watch?v=1UOY-FMm-xo